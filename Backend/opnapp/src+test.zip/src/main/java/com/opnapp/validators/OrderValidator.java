package com.opnapp.validators;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import com.opnapp.exception.InvalidEntityException;
import com.opnapp.models.Order;



public class OrderValidator {

		public static void validateOrder(Order order) throws InvalidEntityException {
			if(order==null) {
				throw new InvalidEntityException("Order object is null");
			}
	        if(!validateOrderDate(order.getOrderDate())) {
	        	throw new InvalidEntityException("Order date must in YYYY-MM-DD");
	        }
	        
	        if(!validateTransactionMode(order.getTransactionMode())) {
	        	throw new InvalidEntityException("Trasaction modes must be 'CASH' OR 'CREDIT CARD'");

	        }
	        if(!validateQuantity(order.getQuantity())){
	        	throw new InvalidEntityException("Quantity must be Integers and atleast '1'");

	        }
	        if(!validateTotalCost(order.getTotalCost())) {
	        	throw new InvalidEntityException("Cost cannot be null and be Positive Number");
	        }
	    }
		
		

	    private static Boolean validateOrderDate(LocalDate orderDate) throws InvalidEntityException {
	    	try {
	            if (orderDate != null) {
	            
	                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	                orderDate.format(formatter);
	                return true;  
	            } else {
	                return false;  
	            }
	        } catch (DateTimeParseException e) {
	            return false; 
	        }
	    }


	    public static boolean validateTransactionMode(String transactionMode) {
	        return ( "CASH".equals(transactionMode) || "CREDIT CARD".equals(transactionMode));
	    }

	    public static boolean validateQuantity(int quantity) {
	        return  quantity >= 1  && quantity!=0;
	    }

	    public static boolean validateTotalCost(double totalCost) {
	        return totalCost > 0;
	    }


		
	    
	}	
