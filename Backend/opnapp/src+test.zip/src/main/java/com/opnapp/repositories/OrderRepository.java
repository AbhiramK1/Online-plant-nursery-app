package com.opnapp.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.opnapp.models.Order;

import jakarta.transaction.Transactional;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

	@Transactional
	@Modifying
	@Query("UPDATE Order a SET a.isDeleted = true WHERE a.bookingOrderId = :bookingOrderId")
	void markAsDeleted(@Param("bookingOrderId") Long bookingOrderId);
}