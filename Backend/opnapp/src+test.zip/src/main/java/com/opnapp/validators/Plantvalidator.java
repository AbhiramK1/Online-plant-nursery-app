package com.opnapp.validators;

import com.opnapp.exception.InvalidEntityException;
import com.opnapp.models.Plant;

public class Plantvalidator {

	public static void validatePlant(Plant plant) throws InvalidEntityException {
		if (plant == null) {
			throw new InvalidEntityException("Plant object is null");
		}

		if (plant.getPlantHeight() == null || plant.getPlantHeight() < 1) {
			throw new InvalidEntityException("Plant height should be a positive integer");
		}

		if (!isValidString(plant.getTypeOfPlant())) {
			throw new InvalidEntityException("Type of plant should not be blank");
		}

		if (!isValidString(plant.getCommonName())) {
			throw new InvalidEntityException("Common name should not be blank");
		}

		if (!isValidString(plant.getExposure())) {
			throw new InvalidEntityException("Exposure should not be blank");
		}

		if (!isValidString(plant.getFlowerColor())) {
			throw new InvalidEntityException("Flower color should not be blank");
		}

		if (!isValidString(plant.getTemperature())) {
			throw new InvalidEntityException("Temperature should not be blank");
		}

		if (plant.getPlantsStock() == null || plant.getPlantsStock() < 1) {
			throw new InvalidEntityException("Plant stock should be a positive integer");
		}

		if (plant.getPlantCost() == null || plant.getPlantCost() < 1) {
			throw new InvalidEntityException("Plant cost should be a positive number");
		}
	}

	private static boolean isValidString(String value) {
		return value != null && !value.isBlank();
	}
}