package com.opnapp.DAO;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.opnapp.exception.InvalidEntityException;
import com.opnapp.models.Plant;
import com.opnapp.repositories.PlantRepo;
import com.opnapp.repositories.PlanterRepository;
import com.opnapp.validators.Plantvalidator;



@Repository
public class PlantDaoImpl implements PlantDao {

	private static final Logger logger = LoggerFactory.getLogger(PlantDaoImpl.class);

	@Autowired
	private PlantRepo plantRepo;
	@Autowired
	private PlanterRepository planterRepository;

	@Override
	public Plant addPlant(Plant plant) throws InvalidEntityException {
		Plantvalidator.validatePlant(plant);
		planterRepository.save(plant.getPlanter());
		logger.info("Adding a new plant");
		plantRepo.save(plant);
		logger.info("Plant added successfully");
		return plant;
	}

	@Override
	public Plant updatePlant(Plant plant) throws InvalidEntityException {
		Plant existingPlant = plantRepo.findById(plant.getPlantId()).orElse(null);

		if (existingPlant == null) {
			logger.info("Plant with ID {} doesn't exist", plant.getPlantId());
			throw new InvalidEntityException("Plant " + plant.getPlantId() + " doesn't exist");
		} else {
			logger.info("Updating plant with ID: {}", plant.getPlantId());
			existingPlant.setPlantHeight(plant.getPlantHeight());
			existingPlant.setBloomTime(plant.getBloomTime());
			existingPlant.setTypeOfPlant(plant.getTypeOfPlant());
			existingPlant.setCommonName(plant.getCommonName());
			existingPlant.setExposure(plant.getExposure());
			existingPlant.setFlowerColor(plant.getFlowerColor());
			existingPlant.setTemperature(plant.getTemperature());
			existingPlant.setDescription(plant.getDescription());
			existingPlant.setPlantsStock(plant.getPlantsStock());
			existingPlant.setPlantCost(plant.getPlantCost());
			Plant updatedPlant = plantRepo.save(existingPlant);
			logger.info("Plant updated successfully");
			return updatedPlant;
		}
	}

	@Override
	public void deletePlant(Plant plant) throws InvalidEntityException {
		logger.info("Marking plant with ID {} as deleted", plant.getPlantId());
		plantRepo.markAsDeleted(plant.getPlantId());
	}

	@Override
	public Plant viewPlantById(Long plantId) throws InvalidEntityException {
		logger.info("Viewing plant with ID: {}", plantId);
		return plantRepo.findPlantById(plantId);
	}

	@Override
	public List<Plant> viewPlantByName(String commonName) throws InvalidEntityException {
		logger.info("Viewing plants by common name: {}", commonName);
		return plantRepo.findBycommonName(commonName);
	}

	@Override
	public List<Plant> viewAllPlants() throws InvalidEntityException {
		logger.info("Viewing all plants");
		return plantRepo.findByIsDeleted(false);
	}

	@Override
	public List<Plant> viewAllPlantsByType(String typeOfPlant) throws InvalidEntityException {
		logger.info("Viewing all plants by type: {}", typeOfPlant);
		return plantRepo.findAllByTypeOfPlant(typeOfPlant);
	}
}
