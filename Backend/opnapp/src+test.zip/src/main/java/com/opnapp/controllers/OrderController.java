package com.opnapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.opnapp.exception.InvalidEntityException;
import com.opnapp.models.Order;
import com.opnapp.services.OrderService;

@CrossOrigin("http://localhost:4200/")
@RestController
@RequestMapping("/orders")
public class OrderController {

	@Autowired
	private OrderService orderService;

	@PostMapping("/addOrder")
	public ResponseEntity<Order> addOrder(@RequestBody Order order) throws InvalidEntityException{

		Order addedOrder = orderService.addOrder(order);
		return ResponseEntity.ok(addedOrder);

	}

	@PutMapping("/update")
	public ResponseEntity<Order> updateOrder(@RequestBody Order order) throws InvalidEntityException{

		Order updatedOrder = orderService.updateOrder(order);
		return ResponseEntity.ok(updatedOrder);

	}

	@DeleteMapping("/deleteOrder")
	public ResponseEntity<String> deleteOrder(@RequestBody Order order) throws InvalidEntityException{
		orderService.deleteOrder(order);
		return ResponseEntity.ok("Order "+order.getBookingOrderId()+" is deleted Successfully");
	}

	 @GetMapping("view/{orderId}")
	    public ResponseEntity<Order> viewOrder(@PathVariable Long orderId) throws InvalidEntityException {
	    	Order viewOrders = orderService.viewOrder(orderId);
	        return ResponseEntity.ok(viewOrders);
	    }

	    @GetMapping("/viewAll")
	    public ResponseEntity<List<Order>> viewAllOrders() throws InvalidEntityException{
	    	List<Order> viewAll = orderService.viewAllOrders();
	        return ResponseEntity.ok(viewAll);
	    }
}
