import { Planter } from "../app.planter-component/app.planter-model";

export class Plant {
    plantId?: any;
  plantHeight: any;
  bloomTime: any;
  typeOfPlant: any;
  commonName: any;
  exposure:any;
  flowerColor:any;
  temperature: any;
  description: any;
  plantsStock: any;
  plantCost: any;
  planter!:Planter;

  
  }
  