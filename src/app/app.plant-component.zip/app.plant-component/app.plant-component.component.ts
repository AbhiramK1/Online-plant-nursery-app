import { Component } from '@angular/core';
import { Planter } from '../app.planter-component/app.planter-model';
import { CurrentUser } from '../CurrentUser';
import { Plant } from './app.plant-model';
import { PlantService } from './app.plant-service';

@Component({
  selector: 'app-app.plant-component',
  templateUrl: './app.plant-component.component.html',
  styleUrls: ['./app.plant-component.component.css']
})
export class AppPlantComponentComponent {
  currentPage = 1; // Current page number
  itemsPerPage = 10; // Number of items per page
 
  get totalPages(): number[] {
    return Array(Math.ceil(this.plantList.length / this.itemsPerPage)).fill(0).map((x, i) => i + 1);
  }
 
  setCurrentPage(page: number) {
    this.currentPage = page;
  }
 
  nextPage() {
    if (this.currentPage < this.totalPages.length) {
      this.currentPage++;
    }
  }
 
  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  userType=CurrentUser.getUserType();
  selection='';
  showMenu=true;
  plant: Plant = new Plant();
  planter: Planter = new Planter();
  plantList: Plant[] = [];
  responseMsg: string = '';
  flag = false;
  plantsByTypeList: Plant[]=[];

  constructor(private plantService: PlantService){}

  addNewPlant(){
    
    this.selection='add';
    this.showMenu=false;
    this.plant.planter=this.planter;
    this.plantService.addPlant(this.plant).subscribe(
      data => {
        this.responseMsg='Plant Added Successfully !';
        console.log(data);
      },
      error => {
      this.responseMsg='Plant Added UnSuccessfully !';
      console.log(error)
      }
    );
  }
  deletePlant(){
    this.selection='delete';
    this.showMenu=false;
    this.plantService.deletePlant(this.plant.plantId).subscribe(
      data => {
        this.responseMsg='Plant Deleted Successfully !';
        console.log(data);
      },
      error => console.log(error)
    );
  }
  searchPlantById(){
    this.showMenu=false;
    this.selection='searchById';
    this.plantService.viewPlantById(this.plant.plantId).subscribe(
      data => {
        this.plantsByTypeList = [];
        this.plantList.push(data);
        console.log(data);
      },
      error => console.log(error)
    );
  }
  viewAllPlants(){
    this.selection='viewAll';
    this.showMenu=false;
    this.plantService.viewAllPlants().subscribe(
      data => {
        console.log(data);
        this.plantList = data;
        this.flag=true;
      },
      error => console.log(error)
    );
  }
  searchPlantByType(){
    this.showMenu=false;
    this.selection='searchByType';
    this.plantService.viewAllPlantByType(this.plant.typeOfPlant).subscribe(
      data => {
        console.log(data);
        this.plantList = data;
        this.flag = true;
      },
      error => console.log(error)
    );
  }
  searchPlantByName(){
    this.showMenu=false;
    this.selection='searchByName';
    this.plantService.viewPlantByName(this.plant.commonName).subscribe(
      data => {
        this.plantsByTypeList = [];
        this.plantList.push(data);
        console.log(data);
        this.flag = true;
      },
      error => console.log(error)
    );
  }
  updatePlant(){
    this.selection='update';
    this.showMenu=false;
    this.plantService.updatePlant(this.plant).subscribe(
      (updatePlant) => {
        console.log('updated Plant' , updatePlant);
        this.responseMsg='Plant Updated Successfully !';
      },
      error => {
      console.error('error updating plant',error)
      }
    );  
  }

  addToCart(){
    
  }
}